# Polymarket Fast Bot (Rust)

Bot de trading de alta velocidade para mercados BTC Up/Down da Polymarket.

## Performance Esperada

| Métrica | Python | Rust |
|---------|--------|------|
| Sign | 700-1000ms | 5-15ms |
| POST | 800-1000ms | 50-100ms |
| **TOTAL** | **1.5-2s** | **~100-150ms** |

## Requisitos

- Rust 1.70+
- Conta Polymarket com fundos
- Private key exportada

## Instalação

```bash
# Clonar/copiar arquivos
cd polymarket-bot-rust

# Configurar credenciais
cp .env.example .env
# Editar .env com suas credenciais

# Compilar em release (otimizado)
cargo build --release
```

## Execução

```bash
# Modo release (mais rápido)
./target/release/polymarket-bot

# Ou com cargo
cargo run --release
```

## Configuração

Edite as constantes no início de `src/main.rs`:

```rust
const TRADE_USD: f64 = 10.0;      // Valor por trade
const HOLD_SEC: u64 = 14;          // Tempo de hold
const COOLDOWN_SEC: u64 = 15;      // Cooldown entre trades
const THRESHOLD: f64 = 0.35;       // Threshold de sinal
const BUY_BUMP: f64 = 0.10;        // Premium no ask para garantir execução
```

## Arquitetura

```
┌─────────────────┐     ┌──────────────────┐
│  Binance WS     │────▶│  Signal Handler  │
│  (aggTrade)     │     └────────┬─────────┘
└─────────────────┘              │
                                 ▼
┌─────────────────┐     ┌──────────────────┐
│  Price Loop     │────▶│  Bot State       │
│  (orderbook)    │     │  (RwLock)        │
└─────────────────┘     └────────┬─────────┘
                                 │
                                 ▼
                        ┌──────────────────┐
                        │  Polymarket API  │
                        │  (order/sell)    │
                        └──────────────────┘
```

## TODO

O código atual tem a estrutura completa mas precisa integrar o `polymarket-client-sdk` 
para execução real de ordens. A parte de signing e POST está marcada com `// TODO`.

Para integração completa, veja:
- https://github.com/Polymarket/rs-clob-client
- https://docs.rs/polymarket-client-sdk

## Notas

- Compile sempre em `--release` para performance máxima
- O bot usa `tcp_nodelay` e connection pooling
- WebSocket reconecta automaticamente em caso de erro
