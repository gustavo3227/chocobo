/*
 * POLYMARKET FAST BOT - RUST
 * 
 * Benefícios vs Python:
 * - Signing ~10x mais rápido (nativo vs FFI)
 * - HTTP com connection pooling real
 * - Zero GC pauses
 * - Async nativo sem GIL
 * 
 * Para rodar:
 * 1. Crie .env com PRIVATE_KEY e FUNDER_ADDRESS
 * 2. cargo build --release
 * 3. ./target/release/polymarket-bot
 */

use std::env;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::RwLock;
use futures::StreamExt;
use anyhow::Result;
use serde::{Deserialize, Serialize};
use tracing::{info, warn, error};

// ============================================================
// PARÂMETROS DE CALIBRAÇÃO
// ============================================================

const TRADE_USD: f64 = 10.0;
const HOLD_SEC: u64 = 14;
const COOLDOWN_SEC: u64 = 15;
const MIN_TIME_LEFT: i64 = 10;

const MIN_PRICE: f64 = 0.20;
const MAX_PRICE: f64 = 0.80;

const BUY_BUMP: f64 = 0.10;
const SELL_BUMP: f64 = 0.0;

const THRESHOLD: f64 = 0.35;
const SIG_CD_MS: u64 = 300;

// ============================================================
// STRUCTS
// ============================================================

#[derive(Debug, Clone)]
struct MarketInfo {
    slug: String,
    up_token: String,
    down_token: String,
    end_time: i64,
}

#[derive(Debug, Clone, Default)]
struct PriceData {
    up_bid: f64,
    up_ask: f64,
    down_bid: f64,
    down_ask: f64,
}

#[derive(Debug, Clone)]
struct Position {
    token: String,
    shares: f64,
    price: f64,
    is_up: bool,
}

#[derive(Debug, Clone)]
struct BotState {
    market: Option<MarketInfo>,
    prices: PriceData,
    position: Option<Position>,
    last_trade: Instant,
    can_trade: bool,
}

impl Default for BotState {
    fn default() -> Self {
        Self {
            market: None,
            prices: PriceData::default(),
            position: None,
            last_trade: Instant::now() - Duration::from_secs(COOLDOWN_SEC + 1),
            can_trade: false,
        }
    }
}

// Binance WebSocket message
#[derive(Debug, Deserialize)]
struct BinanceTrade {
    p: String, // price as string
}

// Gamma API response
#[derive(Debug, Deserialize)]
struct GammaEvent {
    slug: Option<String>,
    #[serde(rename = "endDate")]
    end_date: Option<String>,
    markets: Option<Vec<GammaMarket>>,
}

#[derive(Debug, Deserialize)]
struct GammaMarket {
    outcomes: Option<serde_json::Value>,
    #[serde(rename = "clobTokenIds")]
    clob_token_ids: Option<serde_json::Value>,
}

// ============================================================
// BOT IMPLEMENTATION
// ============================================================

struct Bot {
    state: Arc<RwLock<BotState>>,
    private_key: String,
    funder: String,
    http: reqwest::Client,
}

impl Bot {
    fn new() -> Result<Self> {
        dotenv::dotenv().ok();
        
        let private_key = env::var("PRIVATE_KEY")
            .expect("PRIVATE_KEY must be set");
        let funder = env::var("FUNDER_ADDRESS")
            .expect("FUNDER_ADDRESS must be set");
        
        // HTTP client otimizado
        let http = reqwest::Client::builder()
            .pool_max_idle_per_host(10)
            .pool_idle_timeout(Duration::from_secs(30))
            .tcp_nodelay(true)
            .timeout(Duration::from_secs(5))
            .build()?;
        
        Ok(Self {
            state: Arc::new(RwLock::new(BotState::default())),
            private_key,
            funder,
            http,
        })
    }
    
    async fn load_market(&self) -> Result<Option<MarketInfo>> {
        let now = chrono::Utc::now().timestamp();
        let base = (now / 900) * 900;
        
        for i in 0..3 {
            let ts = base - (i * 900);
            let slug = format!("btc-updown-15m-{}", ts);
            
            let url = format!(
                "https://gamma-api.polymarket.com/events?slug={}",
                slug
            );
            
            match self.http.get(&url).send().await {
                Ok(resp) => {
                    if let Ok(events) = resp.json::<Vec<GammaEvent>>().await {
                        if let Some(event) = events.first() {
                            if let Some(end_str) = &event.end_date {
                                let end_time = chrono::DateTime::parse_from_rfc3339(end_str)
                                    .map(|dt| dt.timestamp())
                                    .unwrap_or(0);
                                
                                if end_time <= now {
                                    continue;
                                }
                                
                                let mut up_token = String::new();
                                let mut down_token = String::new();
                                
                                if let Some(markets) = &event.markets {
                                    for market in markets {
                                        let outcomes = parse_json_or_string(&market.outcomes);
                                        let tokens = parse_json_or_string(&market.clob_token_ids);
                                        
                                        for (idx, outcome) in outcomes.iter().enumerate() {
                                            let outcome_lower = outcome.to_lowercase();
                                            if outcome_lower.contains("up") {
                                                if let Some(tok) = tokens.get(idx) {
                                                    up_token = tok.clone();
                                                }
                                            } else if outcome_lower.contains("down") {
                                                if let Some(tok) = tokens.get(idx) {
                                                    down_token = tok.clone();
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if !up_token.is_empty() && !down_token.is_empty() {
                                    return Ok(Some(MarketInfo {
                                        slug,
                                        up_token,
                                        down_token,
                                        end_time,
                                    }));
                                }
                            }
                        }
                    }
                }
                Err(e) => {
                    warn!("Failed to fetch market: {}", e);
                }
            }
        }
        
        Ok(None)
    }
    
    async fn get_orderbook(&self, token_id: &str) -> Result<(f64, f64)> {
        let url = format!(
            "https://clob.polymarket.com/book?token_id={}",
            token_id
        );
        
        #[derive(Deserialize)]
        struct OrderBook {
            bids: Option<Vec<PriceLevel>>,
            asks: Option<Vec<PriceLevel>>,
        }
        
        #[derive(Deserialize)]
        struct PriceLevel {
            price: String,
        }
        
        let resp = self.http.get(&url).send().await?;
        let book: OrderBook = resp.json().await?;
        
        let bid = book.bids
            .and_then(|b| b.last().map(|p| p.price.parse().unwrap_or(0.0)))
            .unwrap_or(0.0);
        
        let ask = book.asks
            .and_then(|a| a.last().map(|p| p.price.parse().unwrap_or(0.0)))
            .unwrap_or(0.0);
        
        Ok((bid, ask))
    }
    
    async fn price_loop(self: Arc<Self>) {
        loop {
            let mut state = self.state.write().await;
            let now = chrono::Utc::now().timestamp();
            
            // Check if need new market
            let need_new = match &state.market {
                None => true,
                Some(m) => now >= m.end_time,
            };
            
            if need_new {
                state.market = None;
                state.can_trade = false;
                drop(state);
                
                if let Ok(Some(market)) = self.load_market().await {
                    info!("\x1b[96mMkt: {}\x1b[0m", market.slug);
                    let mut state = self.state.write().await;
                    state.market = Some(market);
                }
                
                tokio::time::sleep(Duration::from_millis(500)).await;
                continue;
            }
            
            // Update prices
            if let Some(market) = &state.market {
                let up_token = market.up_token.clone();
                let down_token = market.down_token.clone();
                let end_time = market.end_time;
                let slug = market.slug.clone();
                drop(state);
                
                // Fetch orderbooks in parallel
                let (up_result, down_result) = tokio::join!(
                    self.get_orderbook(&up_token),
                    self.get_orderbook(&down_token)
                );
                
                let mut state = self.state.write().await;
                
                if let Ok((bid, ask)) = up_result {
                    state.prices.up_bid = bid;
                    state.prices.up_ask = ask;
                }
                
                if let Ok((bid, ask)) = down_result {
                    state.prices.down_bid = bid;
                    state.prices.down_ask = ask;
                }
                
                let left = end_time - now;
                
                // Check trade conditions
                let price_ok = state.prices.up_ask > MIN_PRICE 
                    && state.prices.up_ask < MAX_PRICE
                    && state.prices.down_ask > MIN_PRICE 
                    && state.prices.down_ask < MAX_PRICE;
                let time_ok = left > MIN_TIME_LEFT;
                let cooldown_ok = state.last_trade.elapsed() >= Duration::from_secs(COOLDOWN_SEC);
                
                state.can_trade = price_ok && time_ok && cooldown_ok;
                
                let status = if state.can_trade {
                    "\x1b[92mON\x1b[0m"
                } else if !price_ok {
                    "\x1b[91mPRICE\x1b[0m"
                } else if !time_ok {
                    "\x1b[91mTIME\x1b[0m"
                } else {
                    let cd = COOLDOWN_SEC - state.last_trade.elapsed().as_secs();
                    &format!("\x1b[93mCD:{}s\x1b[0m", cd)
                };
                
                println!(
                    "[{}] UP:{:.2}/{:.2} DN:{:.2}/{:.2} | {}:{:02} [{}]",
                    chrono::Local::now().format("%H:%M:%S"),
                    state.prices.up_bid, state.prices.up_ask,
                    state.prices.down_bid, state.prices.down_ask,
                    left / 60, left % 60,
                    status
                );
            }
            
            tokio::time::sleep(Duration::from_millis(500)).await;
        }
    }
    
    async fn execute_buy(&self, is_up: bool) -> Result<bool> {
        let state = self.state.read().await;
        let market = state.market.as_ref().ok_or(anyhow::anyhow!("No market"))?;
        
        let token = if is_up { &market.up_token } else { &market.down_token };
        let ask = if is_up { state.prices.up_ask } else { state.prices.down_ask };
        
        if ask <= 0.0 {
            return Ok(false);
        }
        
        let shares = (TRADE_USD / ask).max(5.0) as i64;
        let price = (ask + BUY_BUMP).min(0.99);
        
        drop(state);
        
        // Aqui usaríamos o polymarket-client-sdk para fazer a ordem
        // Por simplicidade, vou mostrar a estrutura - você precisará
        // adaptar para usar o cliente real
        
        let start = Instant::now();
        
        // Simular a ordem (substituir pelo cliente real)
        info!(
            "   \x1b[93m[ORDER] {} {} shares @ ${:.2}\x1b[0m",
            if is_up { "UP" } else { "DOWN" },
            shares,
            price
        );
        
        // TODO: Implementar com polymarket-client-sdk
        // let order = client.limit_order()
        //     .token_id(token)
        //     .size(shares)
        //     .price(price)
        //     .side(Side::Buy)
        //     .build().await?;
        // let signed = client.sign(&signer, order).await?;
        // let response = client.post_order(signed).await?;
        
        let elapsed = start.elapsed();
        info!("   \x1b[93m[TIMING] total: {}ms\x1b[0m", elapsed.as_millis());
        
        // Atualizar estado
        let mut state = self.state.write().await;
        state.position = Some(Position {
            token: token.clone(),
            shares: shares as f64,
            price: ask,
            is_up,
        });
        state.last_trade = Instant::now();
        
        Ok(true)
    }
    
    async fn execute_sell(&self) -> Result<bool> {
        let state = self.state.read().await;
        let position = state.position.as_ref().ok_or(anyhow::anyhow!("No position"))?;
        
        let bid = if position.is_up { state.prices.up_bid } else { state.prices.down_bid };
        let token = position.token.clone();
        let shares = position.shares;
        
        drop(state);
        
        if bid <= 0.0 {
            return Ok(false);
        }
        
        let price = bid + SELL_BUMP;
        
        let start = Instant::now();
        
        info!(
            "   Selling {} {} @ ${:.2}",
            shares,
            if shares > 0.0 { "shares" } else { "?" },
            price
        );
        
        // TODO: Implementar com polymarket-client-sdk
        
        let elapsed = start.elapsed();
        info!("   \x1b[93m[TIMING SELL] total: {}ms\x1b[0m", elapsed.as_millis());
        
        let mut state = self.state.write().await;
        state.position = None;
        
        Ok(true)
    }
    
    async fn on_signal(self: Arc<Self>, is_up: bool) {
        let can_trade = {
            let state = self.state.read().await;
            state.can_trade
        };
        
        if !can_trade {
            return;
        }
        
        let start = Instant::now();
        
        match self.execute_buy(is_up).await {
            Ok(true) => {
                info!(
                    "\x1b[92mBUY {} {}ms\x1b[0m",
                    if is_up { "UP" } else { "DOWN" },
                    start.elapsed().as_millis()
                );
            }
            Ok(false) | Err(_) => {
                error!("\x1b[91mBUY FAIL\x1b[0m");
                return;
            }
        }
        
        tokio::time::sleep(Duration::from_secs(HOLD_SEC)).await;
        
        for i in 0..3 {
            let start = Instant::now();
            match self.execute_sell().await {
                Ok(true) => {
                    info!("\x1b[92mSELL {}ms\x1b[0m", start.elapsed().as_millis());
                    return;
                }
                _ => {
                    warn!("\x1b[93mSELL attempt {}/3 failed\x1b[0m", i + 1);
                    tokio::time::sleep(Duration::from_secs(3)).await;
                }
            }
        }
        
        error!("\x1b[91mSELL COMPLETELY FAILED!\x1b[0m");
    }
    
    async fn binance_loop(self: Arc<Self>) {
        let url = "wss://fstream.binance.com/ws/btcusdt@aggTrade";
        
        loop {
            info!("\x1b[96mConnecting to Binance...\x1b[0m");
            
            match tokio_tungstenite::connect_async(url).await {
                Ok((ws_stream, _)) => {
                    info!("\x1b[96mBinance ON | Threshold: ${}\x1b[0m", THRESHOLD);
                    
                    let (_, mut read) = ws_stream.split();
                    
                    let mut base_price: Option<f64> = None;
                    let mut last_sig = Instant::now() - Duration::from_millis(SIG_CD_MS + 1);
                    
                    while let Some(msg) = read.next().await {
                        match msg {
                            Ok(tokio_tungstenite::tungstenite::Message::Text(text)) => {
                                if let Ok(trade) = serde_json::from_str::<BinanceTrade>(&text) {
                                    if let Ok(price) = trade.p.parse::<f64>() {
                                        match base_price {
                                            None => {
                                                base_price = Some(price);
                                            }
                                            Some(base) => {
                                                let diff = price - base;
                                                
                                                if diff.abs() >= THRESHOLD 
                                                    && last_sig.elapsed() >= Duration::from_millis(SIG_CD_MS) 
                                                {
                                                    if diff > 0.0 {
                                                        println!("\x1b[92m▲+${:.2}\x1b[0m", diff);
                                                        let bot = Arc::clone(&self);
                                                        tokio::spawn(async move {
                                                            bot.on_signal(true).await;
                                                        });
                                                    } else {
                                                        println!("\x1b[91m▼${:.2}\x1b[0m", diff);
                                                        let bot = Arc::clone(&self);
                                                        tokio::spawn(async move {
                                                            bot.on_signal(false).await;
                                                        });
                                                    }
                                                    base_price = Some(price);
                                                    last_sig = Instant::now();
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            Err(e) => {
                                error!("WebSocket error: {}", e);
                                break;
                            }
                            _ => {}
                        }
                    }
                }
                Err(e) => {
                    error!("Failed to connect: {}", e);
                }
            }
            
            tokio::time::sleep(Duration::from_millis(300)).await;
        }
    }
}

fn parse_json_or_string(value: &Option<serde_json::Value>) -> Vec<String> {
    match value {
        Some(serde_json::Value::Array(arr)) => {
            arr.iter()
                .filter_map(|v| v.as_str().map(String::from))
                .collect()
        }
        Some(serde_json::Value::String(s)) => {
            // Parse string como JSON array
            serde_json::from_str::<Vec<String>>(s).unwrap_or_default()
        }
        _ => vec![],
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt::init();
    
    println!("\x1b[96m=== POLYMARKET FAST BOT (RUST) ===\x1b[0m");
    println!(
        "${} | Hold:{}s | CD:{}s | BuyBump:${} | Threshold:${}",
        TRADE_USD, HOLD_SEC, COOLDOWN_SEC, BUY_BUMP, THRESHOLD
    );
    
    let bot = Arc::new(Bot::new()?);
    
    // Rodar loops em paralelo
    let bot_price = Arc::clone(&bot);
    let bot_binance = Arc::clone(&bot);
    
    tokio::select! {
        _ = bot_price.price_loop() => {}
        _ = bot_binance.binance_loop() => {}
    }
    
    Ok(())
}
