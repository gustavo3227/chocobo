/*
 * POLYMARKET FAST BOT - RUST (VERSÃO COMPLETA)
 * 
 * Usa o cliente oficial rs-clob-client da Polymarket
 * 
 * Cargo.toml deve ter:
 * polymarket-client-sdk = { version = "0.3", features = ["ws"] }
 */

use std::env;
use std::str::FromStr;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::RwLock;
use futures::StreamExt;
use anyhow::Result;
use serde::Deserialize;

use alloy::signers::local::LocalSigner;
use alloy::signers::Signer;
use polymarket_client_sdk::clob::{Client, Config};
use polymarket_client_sdk::clob::types::{Amount, OrderType, Side, SignatureType};
use rust_decimal::Decimal;

// ============================================================
// PARÂMETROS
// ============================================================

const TRADE_USD: f64 = 10.0;
const HOLD_SEC: u64 = 14;
const COOLDOWN_SEC: u64 = 15;
const MIN_TIME_LEFT: i64 = 10;

const MIN_PRICE: f64 = 0.20;
const MAX_PRICE: f64 = 0.80;

const BUY_BUMP: f64 = 0.10;
const SELL_BUMP: f64 = 0.0;

const THRESHOLD: f64 = 0.35;
const SIG_CD_MS: u64 = 300;

const POLYGON: u64 = 137;

// ============================================================
// STRUCTS
// ============================================================

#[derive(Debug, Clone)]
struct MarketInfo {
    slug: String,
    up_token: String,
    down_token: String,
    end_time: i64,
}

#[derive(Debug, Clone, Default)]
struct PriceData {
    up_bid: f64,
    up_ask: f64,
    down_bid: f64,
    down_ask: f64,
}

#[derive(Debug, Clone)]
struct Position {
    token: String,
    shares: f64,
    is_up: bool,
}

#[derive(Debug)]
struct BotState {
    market: Option<MarketInfo>,
    prices: PriceData,
    position: Option<Position>,
    last_trade: Instant,
    can_trade: bool,
}

impl Default for BotState {
    fn default() -> Self {
        Self {
            market: None,
            prices: PriceData::default(),
            position: None,
            last_trade: Instant::now() - Duration::from_secs(COOLDOWN_SEC + 1),
            can_trade: false,
        }
    }
}

#[derive(Debug, Deserialize)]
struct BinanceTrade {
    p: String,
}

#[derive(Debug, Deserialize)]
struct GammaEvent {
    #[serde(rename = "endDate")]
    end_date: Option<String>,
    markets: Option<Vec<GammaMarket>>,
}

#[derive(Debug, Deserialize)]
struct GammaMarket {
    outcomes: Option<serde_json::Value>,
    #[serde(rename = "clobTokenIds")]
    clob_token_ids: Option<serde_json::Value>,
}

// ============================================================
// BOT
// ============================================================

struct Bot {
    state: Arc<RwLock<BotState>>,
    clob_client: Client,
    signer: LocalSigner<alloy::signers::k256::ecdsa::SigningKey>,
    http: reqwest::Client,
    funder: String,
}

impl Bot {
    async fn new() -> Result<Self> {
        dotenv::dotenv().ok();
        
        let private_key = env::var("PRIVATE_KEY")?;
        let funder = env::var("FUNDER_ADDRESS")?;
        let sig_type = env::var("SIGNATURE_TYPE")
            .unwrap_or_else(|_| "1".to_string())
            .parse::<u8>()?;
        
        // Criar signer
        let signer = LocalSigner::from_str(&private_key)?
            .with_chain_id(Some(POLYGON));
        
        // Criar cliente CLOB autenticado
        let config = Config::default();
        let client = Client::new("https://clob.polymarket.com", config)?
            .authentication_builder(&signer)
            .signature_type(match sig_type {
                0 => SignatureType::Eoa,
                1 => SignatureType::Proxy,
                _ => SignatureType::Safe,
            })
            .authenticate()
            .await?;
        
        let http = reqwest::Client::builder()
            .pool_max_idle_per_host(10)
            .tcp_nodelay(true)
            .timeout(Duration::from_secs(5))
            .build()?;
        
        println!("\x1b[92m✓ Cliente CLOB autenticado\x1b[0m");
        
        Ok(Self {
            state: Arc::new(RwLock::new(BotState::default())),
            clob_client: client,
            signer,
            http,
            funder,
        })
    }
    
    async fn load_market(&self) -> Result<Option<MarketInfo>> {
        let now = chrono::Utc::now().timestamp();
        let base = (now / 900) * 900;
        
        for i in 0..3 {
            let ts = base - (i * 900);
            let slug = format!("btc-updown-15m-{}", ts);
            
            let url = format!(
                "https://gamma-api.polymarket.com/events?slug={}",
                slug
            );
            
            if let Ok(resp) = self.http.get(&url).send().await {
                if let Ok(events) = resp.json::<Vec<GammaEvent>>().await {
                    if let Some(event) = events.first() {
                        if let Some(end_str) = &event.end_date {
                            let end_time = chrono::DateTime::parse_from_rfc3339(end_str)
                                .map(|dt| dt.timestamp())
                                .unwrap_or(0);
                            
                            if end_time <= now {
                                continue;
                            }
                            
                            let mut up_token = String::new();
                            let mut down_token = String::new();
                            
                            if let Some(markets) = &event.markets {
                                for market in markets {
                                    let outcomes = parse_value(&market.outcomes);
                                    let tokens = parse_value(&market.clob_token_ids);
                                    
                                    for (idx, outcome) in outcomes.iter().enumerate() {
                                        if outcome.to_lowercase().contains("up") {
                                            if let Some(t) = tokens.get(idx) {
                                                up_token = t.clone();
                                            }
                                        } else if outcome.to_lowercase().contains("down") {
                                            if let Some(t) = tokens.get(idx) {
                                                down_token = t.clone();
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if !up_token.is_empty() && !down_token.is_empty() {
                                return Ok(Some(MarketInfo {
                                    slug,
                                    up_token,
                                    down_token,
                                    end_time,
                                }));
                            }
                        }
                    }
                }
            }
        }
        Ok(None)
    }
    
    async fn get_prices(&self, token: &str) -> Result<(f64, f64)> {
        // Usar cliente CLOB para pegar orderbook
        let book = self.clob_client.orderbook(token).await?;
        
        let bid = book.bids.last()
            .map(|b| b.price.to_string().parse().unwrap_or(0.0))
            .unwrap_or(0.0);
        let ask = book.asks.last()
            .map(|a| a.price.to_string().parse().unwrap_or(0.0))
            .unwrap_or(0.0);
        
        Ok((bid, ask))
    }
    
    async fn execute_buy(&self, is_up: bool) -> Result<bool> {
        let state = self.state.read().await;
        let market = state.market.as_ref().ok_or(anyhow::anyhow!("No market"))?;
        
        let token = if is_up { &market.up_token } else { &market.down_token };
        let ask = if is_up { state.prices.up_ask } else { state.prices.down_ask };
        
        if ask <= 0.0 {
            return Ok(false);
        }
        
        let shares = (TRADE_USD / ask).max(5.0);
        let price = (ask + BUY_BUMP).min(0.99);
        
        let token_id = token.clone();
        drop(state);
        
        let start = Instant::now();
        
        // Criar ordem limite
        let order = self.clob_client
            .limit_order()
            .token_id(&token_id)
            .size(Decimal::from_f64_retain(shares).unwrap_or(Decimal::from(5)))
            .price(Decimal::from_f64_retain(price).unwrap_or(Decimal::from(1) / Decimal::from(2)))
            .side(Side::Buy)
            .build()
            .await?;
        
        let t_build = start.elapsed();
        
        // Assinar
        let signed = self.clob_client.sign(&self.signer, order).await?;
        let t_sign = start.elapsed();
        
        // Enviar como FOK
        let response = self.clob_client.post_order(signed).await?;
        let t_post = start.elapsed();
        
        println!(
            "   \x1b[93m[TIMING] build:{}ms sign:{}ms post:{}ms TOTAL:{}ms\x1b[0m",
            t_build.as_millis(),
            (t_sign - t_build).as_millis(),
            (t_post - t_sign).as_millis(),
            t_post.as_millis()
        );
        
        // Atualizar estado
        let mut state = self.state.write().await;
        state.position = Some(Position {
            token: token_id,
            shares,
            is_up,
        });
        state.last_trade = Instant::now();
        
        Ok(true)
    }
    
    async fn execute_sell(&self) -> Result<bool> {
        let state = self.state.read().await;
        let position = state.position.as_ref().ok_or(anyhow::anyhow!("No position"))?;
        
        let bid = if position.is_up { state.prices.up_bid } else { state.prices.down_bid };
        let token = position.token.clone();
        let shares = position.shares;
        
        drop(state);
        
        if bid <= 0.0 {
            return Ok(false);
        }
        
        let price = bid + SELL_BUMP;
        
        let start = Instant::now();
        
        let order = self.clob_client
            .limit_order()
            .token_id(&token)
            .size(Decimal::from_f64_retain(shares).unwrap_or(Decimal::from(1)))
            .price(Decimal::from_f64_retain(price).unwrap_or(Decimal::from(1) / Decimal::from(2)))
            .side(Side::Sell)
            .build()
            .await?;
        
        let signed = self.clob_client.sign(&self.signer, order).await?;
        let response = self.clob_client.post_order(signed).await?;
        
        println!(
            "   \x1b[93m[TIMING SELL] {}ms\x1b[0m",
            start.elapsed().as_millis()
        );
        
        let mut state = self.state.write().await;
        state.position = None;
        
        Ok(true)
    }
    
    async fn price_loop(self: Arc<Self>) {
        loop {
            let mut state = self.state.write().await;
            let now = chrono::Utc::now().timestamp();
            
            let need_new = match &state.market {
                None => true,
                Some(m) => now >= m.end_time,
            };
            
            if need_new {
                state.market = None;
                state.can_trade = false;
                drop(state);
                
                if let Ok(Some(market)) = self.load_market().await {
                    println!("\x1b[96mMkt: {}\x1b[0m", market.slug);
                    self.state.write().await.market = Some(market);
                }
                
                tokio::time::sleep(Duration::from_millis(500)).await;
                continue;
            }
            
            if let Some(market) = state.market.clone() {
                drop(state);
                
                let (up, down) = tokio::join!(
                    self.get_prices(&market.up_token),
                    self.get_prices(&market.down_token)
                );
                
                let mut state = self.state.write().await;
                
                if let Ok((bid, ask)) = up {
                    state.prices.up_bid = bid;
                    state.prices.up_ask = ask;
                }
                if let Ok((bid, ask)) = down {
                    state.prices.down_bid = bid;
                    state.prices.down_ask = ask;
                }
                
                let left = market.end_time - now;
                
                let price_ok = state.prices.up_ask > MIN_PRICE 
                    && state.prices.up_ask < MAX_PRICE
                    && state.prices.down_ask > MIN_PRICE 
                    && state.prices.down_ask < MAX_PRICE;
                let time_ok = left > MIN_TIME_LEFT;
                let cooldown_ok = state.last_trade.elapsed() >= Duration::from_secs(COOLDOWN_SEC);
                
                state.can_trade = price_ok && time_ok && cooldown_ok;
                
                let status = if state.can_trade {
                    "\x1b[92mON\x1b[0m".to_string()
                } else if !price_ok {
                    "\x1b[91mPRICE\x1b[0m".to_string()
                } else if !time_ok {
                    "\x1b[91mTIME\x1b[0m".to_string()
                } else {
                    format!("\x1b[93mCD:{}s\x1b[0m", 
                        COOLDOWN_SEC.saturating_sub(state.last_trade.elapsed().as_secs()))
                };
                
                println!(
                    "[{}] UP:{:.2}/{:.2} DN:{:.2}/{:.2} | {}:{:02} [{}]",
                    chrono::Local::now().format("%H:%M:%S"),
                    state.prices.up_bid, state.prices.up_ask,
                    state.prices.down_bid, state.prices.down_ask,
                    left / 60, left % 60,
                    status
                );
            }
            
            tokio::time::sleep(Duration::from_millis(500)).await;
        }
    }
    
    async fn on_signal(self: Arc<Self>, is_up: bool) {
        if !self.state.read().await.can_trade {
            return;
        }
        
        let start = Instant::now();
        
        match self.execute_buy(is_up).await {
            Ok(true) => {
                println!(
                    "\x1b[92mBUY {} {}ms\x1b[0m",
                    if is_up { "UP" } else { "DOWN" },
                    start.elapsed().as_millis()
                );
            }
            _ => {
                eprintln!("\x1b[91mBUY FAIL\x1b[0m");
                return;
            }
        }
        
        tokio::time::sleep(Duration::from_secs(HOLD_SEC)).await;
        
        for i in 0..3 {
            if self.execute_sell().await.unwrap_or(false) {
                println!("\x1b[92mSELL OK\x1b[0m");
                return;
            }
            eprintln!("\x1b[93mSELL attempt {}/3 failed\x1b[0m", i + 1);
            tokio::time::sleep(Duration::from_secs(3)).await;
        }
        
        eprintln!("\x1b[91mSELL FAILED\x1b[0m");
    }
    
    async fn binance_loop(self: Arc<Self>) {
        let url = "wss://fstream.binance.com/ws/btcusdt@aggTrade";
        
        loop {
            println!("\x1b[96mConnecting Binance...\x1b[0m");
            
            if let Ok((ws, _)) = tokio_tungstenite::connect_async(url).await {
                println!("\x1b[96mBinance ON | Threshold: ${}\x1b[0m", THRESHOLD);
                
                let (_, mut read) = ws.split();
                let mut base_price: Option<f64> = None;
                let mut last_sig = Instant::now() - Duration::from_millis(SIG_CD_MS + 1);
                
                while let Some(Ok(msg)) = read.next().await {
                    if let tokio_tungstenite::tungstenite::Message::Text(text) = msg {
                        if let Ok(trade) = serde_json::from_str::<BinanceTrade>(&text) {
                            if let Ok(price) = trade.p.parse::<f64>() {
                                match base_price {
                                    None => base_price = Some(price),
                                    Some(base) => {
                                        let diff = price - base;
                                        
                                        if diff.abs() >= THRESHOLD 
                                            && last_sig.elapsed() >= Duration::from_millis(SIG_CD_MS) 
                                        {
                                            let is_up = diff > 0.0;
                                            println!(
                                                "{}${:.2}\x1b[0m",
                                                if is_up { "\x1b[92m▲+" } else { "\x1b[91m▼" },
                                                diff.abs()
                                            );
                                            
                                            let bot = Arc::clone(&self);
                                            tokio::spawn(async move {
                                                bot.on_signal(is_up).await;
                                            });
                                            
                                            base_price = Some(price);
                                            last_sig = Instant::now();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            tokio::time::sleep(Duration::from_millis(300)).await;
        }
    }
}

fn parse_value(v: &Option<serde_json::Value>) -> Vec<String> {
    match v {
        Some(serde_json::Value::Array(arr)) => {
            arr.iter().filter_map(|x| x.as_str().map(String::from)).collect()
        }
        Some(serde_json::Value::String(s)) => {
            serde_json::from_str(s).unwrap_or_default()
        }
        _ => vec![],
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    println!("\x1b[96m=== POLYMARKET FAST BOT (RUST) ===\x1b[0m");
    
    let bot = Arc::new(Bot::new().await?);
    
    let b1 = Arc::clone(&bot);
    let b2 = Arc::clone(&bot);
    
    tokio::select! {
        _ = b1.price_loop() => {}
        _ = b2.binance_loop() => {}
    }
    
    Ok(())
}
